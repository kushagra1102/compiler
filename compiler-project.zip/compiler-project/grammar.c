#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include "our_stack.c"
#include "our_tree.c"

#define NO_OF_RULES 
#define NO_OF_TERMINALS
#define NO_OF_NON_TERMINALS

// 0. Data Structures & Definitions
typedef struct Symbol{
    union{
        Terminal t;
        NonTerminal nt;
    };
    bool is_terminal;
}Symbol;

typedef struct SymbolNode{
    Symbol symbol;
    struct SymbolNode *next;
} SymbolNode;

typedef struct Rule{
    NonTerminal LHS;
    SymbolNode* head;
    struct Rule* next;
    int length;
    int ruleNo;
} Rule;

typedef struct Rules{
    NonTerminal LHS;
    Rule* head;
    int nonTerminalNo;
    int noOfRules;
} Rules;

// TODO : define startsymbol = new symbol(malloc/calloc)

// grammar is an array of rules
typedef struct Grammar{
    Rules** rules;
    int noOfRules;
} Grammar;


symbol first_sets[NO_OF_NON_TERMINALS][25];
symbol follow_sets[NO_OF_NON_TERMINALS][25];

// parse table is 2d matrix with no of rows = no of non-terminals and no of columns = no of terminals
// each entry in the parse table stores the Rule number corresponding to the grammar array
int parseTable[NO_OF_NON_TERMINALS][NO_OF_TERMINALS];

enum {
    PLUS,
    MINUS,

}Terminal;
enum {
    program,

}NonTerminal;






// 1. Generate Grammar
void generate_grammar(FILE* fp){}









// 2. First & Follow Set Automation
void initialise_first_sets(set<symbol> first_sets[]){

}

int nonTerminal_to_ruleNo(Rule grammar[], NonTerminal nt){

}

// ruleNo ->specifies the non-terminal
void compute_first_set(Rule* grammar, NonTerminal nt, int** first_sets){

    Rules* rules = grammar[ruleNo];
    Rule* temp = rules->head;

    for(int i=0; i<rules->nonTerminalNo; i++){
        SymbolNode * temp2 = temp->head;

        for (int j = 0; i < temp->length; j++)
        {
            if(temp2->symbol->is_terminal ==0){
                addToSet(first_set[nt], temp2->symbol.t);
                break;
            }
            else{
                computer_first_set(grammar, temp2->symbol.nt, first_set);
                union_set(first_set[nt], first_set[temp2->symbol.nt]);

                if(!checkPresence(first_set[temp2->symbol.nt], EPSILOn)){
                    break;
                }
            }
            temp2= temp2->next;
        }
        

        // // if temp is a terminal
        // if(temp->symbol.isTerminal == true){
        //     first_sets[ruleNo].insert(temp->symbol);
        //     break;
        // }

        // // if temp is a non-terminal
        // else{
        //     NonTerminal nt2 = temp->symbol.nt;
        //     int newRuleNo = nonTerminal_to_ruleNo(grammar,nt2);
            
        //     // check if first set of new non terminal is computed or not. If not, compute it
        //     if(first_sets[newRuleNo].empty() == true){
        //         compute_first_set(grammar,nt2,newRuleNo,first_sets);
        //     }

        //     // add all elements in first set of new non terminal to first set of given non terminal
        //     iterator::set<symbol> it = first_sets[newRuleNo].begin();
        //     while(it != first_sets[newRuleNo].end()){
        //         first_sets[ruleNo].insert(*it);
        //         it++;
        //     }

        //     // if first set of new non terminal does not contain epsilon, we can break the loop
        //     if(!first_sets[newRuleNo].contain('epsilon'))
        //         break;
        // }

        // temp = temp->next;
    }
}

void compute_follow_set(Rule grammar[], NonTerminal nt, int ruleNo, set<symbol>* first_sets){

}












// 3. Parse Table Creation(Automated)
















// 4. Parse Tree and Parsing Algorithm

ParseTree* parseInputSourceCode(FILE* fp, int** parseTable, int* syntaxErorrs, Rule* grammar){
	

    // Initialise Parse Tree
    ParseTree* tree = (ParseTree*)malloc(sizeof(ParseTree));
    tree->root = createTreeNode(startsymbol,NULL);
    TreeNode* temp = tree->root;

    // Initialise PDA : Stack
    Stack* s = (Stack*)malloc(sizeof(Stack));
    s->size = 0;
    s->top = NULL;
    TreeNode* dollarNode = createTreeNode('$',NULL);
	StackNode* dollar = createStackNode(dollarNode);
    pushToStack(s,dollar);
    pushToStack(s,tree->root);


    // Fetch token from Lexer
    Token* L = getNextToken(fp);


    while(L != NULL){

        //TODO: error 4
        // Take a more in-depth view at errors before starting the parsing process
        if(s->size == 0){
            // report erorr of type 4 : Input is not consumed and stack is empty
        }
        // more error detection logic






        // Parsing Algorithm Begins

        StackNode* stackTopNode = popFromStack(s);
        TreeNode* treeNode = stackTopNode->treeNodePointer;




        // Case 1: Top of Stack is a terminal
        if(treeNode->symbol.isTerminal){

            // Case 1.a: Top of Stack matches with Lookahead Token
            if(treeNode->symbol.terminal ==  L.type){
                treeNode->token = L;
                L = getNextToken(fp);
            }
            // Case 1.b: Top of Stack does not match with Lookahead Token
            else{
                // report error Type 1 : Terminal Mismatch
            }

        }




        // Case 2: Top of Stack is a non-terminal
        else {
            
            NonTerminal nt = treeNode->symbol.nt;
            Terminal t = L.type;
            // TODO : t and nt are not yet mapped to an integer
            int ruleNo = parseTable[(int)nt][(int)t];

            // Case 2a: Valid Rule Present in ParseTable
            if(ruleNo != -1){
                // TODO : access rule from ruleNo
                Rule r = grammar[ruleNo];
                addChildrenOfTree(treeNode,r);
                addToStack(s,treeNode);
            }
            // Case 2.b: Rule not Present in ParseTable
            else{
                // report erorr of type 2 : NULL access from parse table
            }

        }

    }

    if(!s.empty()){
        // report error of type 3 : Input is consumed but stack is not empty
    }

}